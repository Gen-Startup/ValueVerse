"use client";

import { useEffect, useState } from "react";
import { ArrowRight, Sparkles, TrendingDown } from "lucide-react";

export default function HomePage() {
  const [featuredProducts, setFeaturedProducts] = useState([]);
  const [allProducts, setAllProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchFeaturedProducts();
  }, []);

  const fetchFeaturedProducts = async () => {
    try {
      const response = await fetch("/api/products");
      if (!response.ok) throw new Error("Failed to fetch products");
      const data = await response.json();
      setAllProducts(data.products);
      setFeaturedProducts(
        data.products.filter((p) => p.is_featured).slice(0, 6),
      );
    } catch (error) {
      console.error("Error fetching featured products:", error);
    } finally {
      setLoading(false);
    }
  };

  const calculateSavings = (original, discounted) => {
    return Math.round(((original - discounted) / original) * 100);
  };

  const calculateAverageSavings = () => {
    if (allProducts.length === 0) return 0;
    const totalSavings = allProducts.reduce((sum, product) => {
      return (
        sum + calculateSavings(product.original_price, product.discounted_price)
      );
    }, 0);
    return Math.round(totalSavings / allProducts.length);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <a href="/" className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                ValueVerse
              </span>
            </a>
            <div className="flex items-center gap-2">
              <a
                href="/dashboard"
                className="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors font-medium"
              >
                Dashboard
              </a>
              <a
                href="/subscriptions"
                className="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors font-medium"
              >
                Subscriptions
              </a>
              <a
                href="/browse"
                className="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors font-medium"
              >
                Browse All
              </a>
              <a
                href="/admin"
                className="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors font-medium"
              >
                Admin
              </a>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24">
        <div className="text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-100 text-indigo-700 rounded-full text-sm font-medium mb-6">
            <TrendingDown className="w-4 h-4" />
            Save up to 70% on premium subscriptions
          </div>
          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-gray-900 mb-6">
            Premium Tools,
            <br />
            <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
              Unbeatable Prices
            </span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Access the best software and tools at a fraction of the original
            cost. No compromises, just incredible value.
          </p>
          <a
            href="/browse"
            className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl hover:from-indigo-700 hover:to-purple-700 transition-all font-semibold text-lg shadow-lg hover:shadow-xl"
          >
            Explore Deals
            <ArrowRight className="w-5 h-5" />
          </a>
        </div>
      </section>

      {/* Featured Products */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-1">
              Featured Deals
            </h2>
            <p className="text-gray-600">
              Hand-picked premium tools with exclusive discounts
            </p>
          </div>
          <a
            href="/browse"
            className="text-indigo-600 hover:text-indigo-700 font-medium flex items-center gap-1"
          >
            View all
            <ArrowRight className="w-4 h-4" />
          </a>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div
                key={i}
                className="bg-white rounded-2xl p-6 shadow-sm animate-pulse"
              >
                <div className="h-6 bg-gray-200 rounded w-3/4 mb-4"></div>
                <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
                <div className="h-4 bg-gray-200 rounded w-5/6"></div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredProducts.map((product) => (
              <a
                key={product.id}
                href={`/product/${product.id}`}
                className="group bg-white rounded-2xl p-6 shadow-sm hover:shadow-xl transition-all border border-gray-100 hover:border-indigo-200"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="px-3 py-1 bg-indigo-100 text-indigo-700 rounded-full text-xs font-semibold">
                    {product.category}
                  </div>
                  {calculateSavings(
                    product.original_price,
                    product.discounted_price,
                  ) > 0 && (
                    <div className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-bold">
                      Save{" "}
                      {calculateSavings(
                        product.original_price,
                        product.discounted_price,
                      )}
                      %
                    </div>
                  )}
                </div>

                <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-indigo-600 transition-colors">
                  {product.name}
                </h3>
                <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                  {product.description}
                </p>

                {/* Features */}
                {product.features && product.features.length > 0 && (
                  <div className="mb-4">
                    <ul className="space-y-1">
                      {product.features.slice(0, 3).map((feature, idx) => (
                        <li
                          key={idx}
                          className="flex items-start gap-2 text-xs text-gray-700"
                        >
                          <span className="text-green-500 mt-0.5">✓</span>
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                <div className="flex items-end gap-2 mb-4">
                  <span className="text-3xl font-bold text-gray-900">
                    ${product.discounted_price}
                  </span>
                  {product.original_price > product.discounted_price && (
                    <span className="text-lg text-gray-400 line-through mb-1">
                      ${product.original_price}
                    </span>
                  )}
                  <span className="text-sm text-gray-500 mb-1">
                    /
                    {product.billing_period === "yearly"
                      ? "year"
                      : product.billing_period === "quarterly"
                        ? "quarter"
                        : product.billing_period === "custom"
                          ? "period"
                          : "month"}
                  </span>
                </div>

                <div className="flex items-center gap-2 text-indigo-600 font-medium group-hover:gap-3 transition-all">
                  View Details
                  <ArrowRight className="w-4 h-4" />
                </div>
              </a>
            ))}
          </div>
        )}
      </section>

      {/* Stats Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-3xl p-12 text-white">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="text-5xl font-bold mb-2">
                {allProducts.length}+
              </div>
              <div className="text-indigo-100">Premium Tools</div>
            </div>
            <div>
              <div className="text-5xl font-bold mb-2">
                {calculateAverageSavings()}%
              </div>
              <div className="text-indigo-100">Average Savings</div>
            </div>
            <div>
              <div className="text-5xl font-bold mb-2">10K+</div>
              <div className="text-indigo-100">Happy Customers</div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t bg-white mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center text-gray-600">
            <p>
              &copy; 2025 ValueVerse. Premium subscriptions at unbeatable
              prices.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
