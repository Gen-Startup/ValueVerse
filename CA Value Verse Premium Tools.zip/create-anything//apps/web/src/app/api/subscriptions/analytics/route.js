import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const orgId = searchParams.get("org_id") || 1;

    // Total spend
    const monthlySpend = await sql`
      SELECT 
        SUM(CASE WHEN billing_cycle = 'monthly' THEN price ELSE 0 END) as monthly_total,
        SUM(CASE WHEN billing_cycle = 'yearly' THEN price / 12 ELSE 0 END) as yearly_monthly,
        SUM(CASE WHEN billing_cycle = 'quarterly' THEN price / 3 ELSE 0 END) as quarterly_monthly
      FROM user_subscriptions
      WHERE organization_id = ${orgId} AND status = 'active'
    `;

    const totalMonthlySpend =
      (parseFloat(monthlySpend[0]?.monthly_total) || 0) +
      (parseFloat(monthlySpend[0]?.yearly_monthly) || 0) +
      (parseFloat(monthlySpend[0]?.quarterly_monthly) || 0);

    // Upcoming renewals (next 30 days)
    const upcomingRenewals = await sql`
      SELECT COUNT(*) as count, SUM(price) as total_amount
      FROM user_subscriptions
      WHERE organization_id = ${orgId} 
        AND status = 'active'
        AND renewal_date BETWEEN CURRENT_DATE AND CURRENT_DATE + INTERVAL '30 days'
    `;

    // Active subscriptions
    const activeCount = await sql`
      SELECT COUNT(*) as count
      FROM user_subscriptions
      WHERE organization_id = ${orgId} AND status = 'active'
    `;

    // Spend by category
    const byCategory = await sql`
      SELECT category, COUNT(*) as count, SUM(price) as total
      FROM user_subscriptions
      WHERE organization_id = ${orgId} AND status = 'active'
      GROUP BY category
      ORDER BY total DESC
    `;

    // Unused licenses (not used in 30+ days)
    const unusedLicenses = await sql`
      SELECT COUNT(*) as count
      FROM user_subscriptions
      WHERE organization_id = ${orgId} 
        AND status = 'active'
        AND (last_used_at IS NULL OR last_used_at < CURRENT_TIMESTAMP - INTERVAL '30 days')
    `;

    // Recent subscriptions
    const recentSubscriptions = await sql`
      SELECT us.*, v.name as vendor_name
      FROM user_subscriptions us
      LEFT JOIN vendors v ON us.vendor_id = v.id
      WHERE us.organization_id = ${orgId}
      ORDER BY us.created_at DESC
      LIMIT 5
    `;

    return Response.json({
      summary: {
        total_monthly_spend: totalMonthlySpend.toFixed(2),
        total_annual_spend: (totalMonthlySpend * 12).toFixed(2),
        active_subscriptions: parseInt(activeCount[0]?.count) || 0,
        upcoming_renewals_count: parseInt(upcomingRenewals[0]?.count) || 0,
        upcoming_renewals_amount:
          parseFloat(upcomingRenewals[0]?.total_amount) || 0,
        unused_licenses: parseInt(unusedLicenses[0]?.count) || 0,
      },
      by_category: byCategory,
      recent_subscriptions: recentSubscriptions,
    });
  } catch (error) {
    console.error("Error fetching analytics:", error);
    return Response.json(
      { error: "Failed to fetch analytics" },
      { status: 500 },
    );
  }
}
