import sql from "@/app/api/utils/sql";

// Get a single subscription
export async function GET(request, { params }) {
  try {
    const { id } = params;

    const result = await sql`
      SELECT 
        us.*,
        v.name as vendor_name,
        v.website as vendor_website,
        v.support_email as vendor_support_email,
        v.cancel_link as vendor_cancel_link,
        p.name as owner_name,
        p.email as owner_email
      FROM user_subscriptions us
      LEFT JOIN vendors v ON us.vendor_id = v.id
      LEFT JOIN profiles p ON us.profile_id = p.id
      WHERE us.id = ${id}
    `;

    if (result.length === 0) {
      return Response.json(
        { error: "Subscription not found" },
        { status: 404 },
      );
    }

    // Get assignments
    const assignments = await sql`
      SELECT sa.*, p.name, p.email
      FROM subscription_assignments sa
      JOIN profiles p ON sa.profile_id = p.id
      WHERE sa.subscription_id = ${id} AND sa.removed_at IS NULL
    `;

    // Get invoices
    const invoices = await sql`
      SELECT * FROM invoices
      WHERE subscription_id = ${id}
      ORDER BY invoice_date DESC
    `;

    return Response.json({
      subscription: result[0],
      assignments,
      invoices,
    });
  } catch (error) {
    console.error("Error fetching subscription:", error);
    return Response.json(
      { error: "Failed to fetch subscription" },
      { status: 500 },
    );
  }
}

// Update a subscription
export async function PUT(request, { params }) {
  try {
    const { id } = params;
    const body = await request.json();

    let setClauses = [];
    let values = [];
    let paramCount = 0;

    const allowedFields = [
      "name",
      "category",
      "seats",
      "price",
      "currency",
      "billing_cycle",
      "start_date",
      "renewal_date",
      "status",
      "payment_method",
      "contract_terms",
      "last_used_at",
    ];

    for (const field of allowedFields) {
      if (body[field] !== undefined) {
        paramCount++;
        setClauses.push(`${field} = $${paramCount}`);
        values.push(body[field]);
      }
    }

    if (setClauses.length === 0) {
      return Response.json({ error: "No fields to update" }, { status: 400 });
    }

    // Add updated_at
    paramCount++;
    setClauses.push(`updated_at = $${paramCount}`);
    values.push(new Date().toISOString());

    paramCount++;
    values.push(id);

    const query = `UPDATE user_subscriptions SET ${setClauses.join(", ")} WHERE id = $${paramCount} RETURNING *`;
    const result = await sql(query, values);

    if (result.length === 0) {
      return Response.json(
        { error: "Subscription not found" },
        { status: 404 },
      );
    }

    // Audit log
    await sql`
      INSERT INTO audit_logs (action_type, resource_type, resource_id, payload)
      VALUES ('update', 'subscription', ${id}, ${JSON.stringify(body)})
    `;

    return Response.json({ subscription: result[0] });
  } catch (error) {
    console.error("Error updating subscription:", error);
    return Response.json(
      { error: "Failed to update subscription" },
      { status: 500 },
    );
  }
}

// Delete a subscription
export async function DELETE(request, { params }) {
  try {
    const { id } = params;

    const result = await sql`
      UPDATE user_subscriptions 
      SET status = 'cancelled', updated_at = CURRENT_TIMESTAMP
      WHERE id = ${id}
      RETURNING *
    `;

    if (result.length === 0) {
      return Response.json(
        { error: "Subscription not found" },
        { status: 404 },
      );
    }

    // Audit log
    await sql`
      INSERT INTO audit_logs (action_type, resource_type, resource_id)
      VALUES ('delete', 'subscription', ${id})
    `;

    return Response.json({ message: "Subscription cancelled successfully" });
  } catch (error) {
    console.error("Error deleting subscription:", error);
    return Response.json(
      { error: "Failed to delete subscription" },
      { status: 500 },
    );
  }
}
