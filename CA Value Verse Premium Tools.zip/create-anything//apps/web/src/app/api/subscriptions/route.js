import sql from "@/app/api/utils/sql";

// Get all subscriptions for an organization
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const orgId = searchParams.get("org_id") || 1; // Default org for MVP
    const status = searchParams.get("status");
    const category = searchParams.get("category");

    let query = `
      SELECT 
        us.*,
        v.name as vendor_name,
        v.website as vendor_website,
        p.name as owner_name,
        p.email as owner_email,
        (SELECT COUNT(*) FROM subscription_assignments WHERE subscription_id = us.id AND removed_at IS NULL) as assigned_seats
      FROM user_subscriptions us
      LEFT JOIN vendors v ON us.vendor_id = v.id
      LEFT JOIN profiles p ON us.profile_id = p.id
      WHERE us.organization_id = $1
    `;

    const values = [orgId];
    let paramCount = 1;

    if (status) {
      paramCount++;
      query += ` AND us.status = $${paramCount}`;
      values.push(status);
    }

    if (category) {
      paramCount++;
      query += ` AND us.category = $${paramCount}`;
      values.push(category);
    }

    query += " ORDER BY us.renewal_date ASC";

    const subscriptions = await sql(query, values);

    return Response.json({ subscriptions });
  } catch (error) {
    console.error("Error fetching subscriptions:", error);
    return Response.json(
      { error: "Failed to fetch subscriptions" },
      { status: 500 },
    );
  }
}

// Create a new subscription
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      organization_id = 1, // Default for MVP
      profile_id,
      name,
      vendor_name,
      category,
      seats = 1,
      price,
      currency = "USD",
      billing_cycle = "monthly",
      start_date,
      renewal_date,
      payment_method,
      contract_terms,
    } = body;

    if (!name || !category || !price || !start_date || !renewal_date) {
      return Response.json(
        { error: "Missing required fields" },
        { status: 400 },
      );
    }

    // Create or find vendor
    let vendorId = null;
    if (vendor_name) {
      const existingVendor = await sql`
        SELECT id FROM vendors WHERE organization_id = ${organization_id} AND LOWER(name) = LOWER(${vendor_name})
      `;

      if (existingVendor.length > 0) {
        vendorId = existingVendor[0].id;
      } else {
        const newVendor = await sql`
          INSERT INTO vendors (organization_id, name)
          VALUES (${organization_id}, ${vendor_name})
          RETURNING id
        `;
        vendorId = newVendor[0].id;
      }
    }

    // Create subscription
    const result = await sql`
      INSERT INTO user_subscriptions (
        organization_id, profile_id, name, vendor_id, category, seats, 
        price, currency, billing_cycle, start_date, renewal_date, 
        payment_method, contract_terms, status
      )
      VALUES (
        ${organization_id}, ${profile_id || null}, ${name}, ${vendorId}, ${category}, ${seats},
        ${price}, ${currency}, ${billing_cycle}, ${start_date}, ${renewal_date},
        ${payment_method || null}, ${contract_terms || null}, 'active'
      )
      RETURNING *
    `;

    // Create audit log
    await sql`
      INSERT INTO audit_logs (organization_id, action_type, resource_type, resource_id, payload)
      VALUES (${organization_id}, 'create', 'subscription', ${result[0].id}, ${JSON.stringify(body)})
    `;

    return Response.json({ subscription: result[0] });
  } catch (error) {
    console.error("Error creating subscription:", error);
    return Response.json(
      { error: "Failed to create subscription" },
      { status: 500 },
    );
  }
}
