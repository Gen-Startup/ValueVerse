import sql from "@/app/api/utils/sql";

// Get all products with optional filtering
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get("category");
    const featured = searchParams.get("featured");

    let query = "SELECT * FROM products WHERE 1=1";
    const values = [];
    let paramCount = 0;

    if (category) {
      paramCount++;
      query += ` AND category = $${paramCount}`;
      values.push(category);
    }

    if (featured === "true") {
      query += " AND is_featured = true";
    }

    query += " ORDER BY created_at DESC";

    const products = await sql(query, values);

    return Response.json({ products });
  } catch (error) {
    console.error("Error fetching products:", error);
    return Response.json(
      { error: "Failed to fetch products" },
      { status: 500 },
    );
  }
}

// Create a new product
export async function POST(request) {
  try {
    const body = await request.json();
    const {
      name,
      description,
      category,
      original_price,
      discounted_price,
      billing_period,
      features,
      image_url,
      is_featured,
    } = body;

    if (
      !name ||
      !description ||
      !category ||
      !original_price ||
      !discounted_price
    ) {
      return Response.json(
        { error: "Missing required fields" },
        { status: 400 },
      );
    }

    const result = await sql`
      INSERT INTO products (name, description, category, original_price, discounted_price, billing_period, features, image_url, is_featured)
      VALUES (${name}, ${description}, ${category}, ${original_price}, ${discounted_price}, ${billing_period || "monthly"}, ${features || []}, ${image_url || null}, ${is_featured || false})
      RETURNING *
    `;

    return Response.json({ product: result[0] });
  } catch (error) {
    console.error("Error creating product:", error);
    return Response.json(
      { error: "Failed to create product" },
      { status: 500 },
    );
  }
}
