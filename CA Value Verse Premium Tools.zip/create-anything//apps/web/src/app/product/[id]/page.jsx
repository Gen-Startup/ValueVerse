"use client";

import { useEffect, useState } from "react";
import { ArrowLeft, Check, Sparkles, ShoppingCart } from "lucide-react";

export default function ProductPage({ params }) {
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProduct();
  }, []);

  const fetchProduct = async () => {
    try {
      const response = await fetch(`/api/products/${params.id}`);
      if (!response.ok) throw new Error("Failed to fetch product");
      const data = await response.json();
      setProduct(data.product);
    } catch (error) {
      console.error("Error fetching product:", error);
    } finally {
      setLoading(false);
    }
  };

  const calculateSavings = (original, discounted) => {
    return Math.round(((original - discounted) / original) * 100);
  };

  const calculateMonthlySavings = (original, discounted) => {
    return (original - discounted).toFixed(2);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">
            Product not found
          </h1>
          <a href="/browse" className="text-indigo-600 hover:text-indigo-700">
            Browse all products
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <a href="/" className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                ValueVerse
              </span>
            </a>
            <a
              href="/browse"
              className="flex items-center gap-2 text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Browse
            </a>
          </div>
        </div>
      </header>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-3xl shadow-xl overflow-hidden">
          {/* Product Header */}
          <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-8 text-white">
            <div className="flex items-start justify-between mb-4">
              <div className="px-3 py-1 bg-white/20 backdrop-blur-sm rounded-full text-sm font-semibold">
                {product.category}
              </div>
              <div className="px-4 py-2 bg-green-500 rounded-full text-sm font-bold">
                Save{" "}
                {calculateSavings(
                  product.original_price,
                  product.discounted_price,
                )}
                %
              </div>
            </div>
            <h1 className="text-4xl font-bold mb-3">{product.name}</h1>
            <p className="text-indigo-100 text-lg">{product.description}</p>
          </div>

          {/* Pricing Section */}
          <div className="p-8 border-b">
            <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6">
              <div>
                <div className="text-sm text-gray-500 mb-2">Your Price</div>
                <div className="flex items-end gap-3 mb-2">
                  <span className="text-5xl font-bold text-gray-900">
                    ${product.discounted_price}
                  </span>
                  <span className="text-2xl text-gray-400 line-through mb-2">
                    ${product.original_price}
                  </span>
                  <span className="text-lg text-gray-600 mb-2">
                    /{product.billing_period}
                  </span>
                </div>
                <div className="text-green-600 font-semibold">
                  You save $
                  {calculateMonthlySavings(
                    product.original_price,
                    product.discounted_price,
                  )}{" "}
                  per {product.billing_period}
                </div>
              </div>

              <button className="flex items-center justify-center gap-2 px-8 py-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl hover:from-indigo-700 hover:to-purple-700 transition-all font-semibold text-lg shadow-lg hover:shadow-xl">
                <ShoppingCart className="w-5 h-5" />
                Get This Deal
              </button>
            </div>
          </div>

          {/* Features Section */}
          <div className="p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">
              What's Included
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {product.features.map((feature, index) => (
                <div key={index} className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-6 h-6 bg-green-100 rounded-full flex items-center justify-center mt-0.5">
                    <Check className="w-4 h-4 text-green-600" />
                  </div>
                  <span className="text-gray-700">{feature}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Value Proposition */}
          <div className="p-8 bg-gradient-to-r from-indigo-50 to-purple-50">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Why Choose ValueVerse?
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <div className="text-3xl font-bold text-indigo-600 mb-2">
                  {calculateSavings(
                    product.original_price,
                    product.discounted_price,
                  )}
                  %
                </div>
                <div className="text-gray-700">Cheaper than retail</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-indigo-600 mb-2">
                  100%
                </div>
                <div className="text-gray-700">Authentic licenses</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-indigo-600 mb-2">
                  24/7
                </div>
                <div className="text-gray-700">Customer support</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
