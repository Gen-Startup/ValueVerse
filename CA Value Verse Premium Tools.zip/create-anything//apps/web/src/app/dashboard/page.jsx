"use client";

import { useEffect, useState } from "react";
import {
  Calendar,
  DollarSign,
  TrendingUp,
  AlertCircle,
  Plus,
  Sparkles,
  Package,
  Users,
} from "lucide-react";

export default function DashboardPage() {
  const [analytics, setAnalytics] = useState(null);
  const [subscriptions, setSubscriptions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [analyticsRes, subsRes] = await Promise.all([
        fetch("/api/subscriptions/analytics"),
        fetch("/api/subscriptions"),
      ]);

      if (analyticsRes.ok) {
        const data = await analyticsRes.json();
        setAnalytics(data);
      }

      if (subsRes.ok) {
        const data = await subsRes.json();
        setSubscriptions(data.subscriptions);
      }
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
    } finally {
      setLoading(false);
    }
  };

  const getUpcomingRenewals = () => {
    const now = new Date();
    const thirtyDaysFromNow = new Date(
      now.getTime() + 30 * 24 * 60 * 60 * 1000,
    );

    return subscriptions
      .filter((sub) => {
        const renewalDate = new Date(sub.renewal_date);
        return (
          sub.status === "active" &&
          renewalDate >= now &&
          renewalDate <= thirtyDaysFromNow
        );
      })
      .sort((a, b) => new Date(a.renewal_date) - new Date(b.renewal_date));
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  const getDaysUntilRenewal = (renewalDate) => {
    const now = new Date();
    const renewal = new Date(renewalDate);
    const diffTime = renewal - now;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  const upcomingRenewals = getUpcomingRenewals();

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <a href="/" className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                ValueVerse
              </span>
            </a>
            <nav className="flex items-center gap-6">
              <a href="/dashboard" className="text-indigo-600 font-medium">
                Dashboard
              </a>
              <a
                href="/subscriptions"
                className="text-gray-600 hover:text-gray-900"
              >
                Subscriptions
              </a>
              <a href="/browse" className="text-gray-600 hover:text-gray-900">
                Marketplace
              </a>
              <a href="/admin" className="text-gray-600 hover:text-gray-900">
                Admin
              </a>
            </nav>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              Subscription Management
            </h1>
            <p className="text-gray-600 mt-1">
              Track and manage all your software subscriptions
            </p>
          </div>
          <a
            href="/subscriptions/new"
            className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl hover:from-indigo-700 hover:to-purple-700 transition-all font-semibold shadow-lg"
          >
            <Plus className="w-5 h-5" />
            Add Subscription
          </a>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-indigo-100 rounded-xl flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-indigo-600" />
              </div>
            </div>
            <div className="text-3xl font-bold text-gray-900 mb-1">
              ${analytics?.summary?.total_monthly_spend || "0.00"}
            </div>
            <div className="text-sm text-gray-600">Monthly Spend</div>
            <div className="text-xs text-gray-500 mt-1">
              ${analytics?.summary?.total_annual_spend || "0.00"}/year
            </div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                <Package className="w-6 h-6 text-green-600" />
              </div>
            </div>
            <div className="text-3xl font-bold text-gray-900 mb-1">
              {analytics?.summary?.active_subscriptions || 0}
            </div>
            <div className="text-sm text-gray-600">Active Subscriptions</div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
                <Calendar className="w-6 h-6 text-orange-600" />
              </div>
            </div>
            <div className="text-3xl font-bold text-gray-900 mb-1">
              {analytics?.summary?.upcoming_renewals_count || 0}
            </div>
            <div className="text-sm text-gray-600">Upcoming Renewals</div>
            <div className="text-xs text-gray-500 mt-1">Next 30 days</div>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center">
                <AlertCircle className="w-6 h-6 text-red-600" />
              </div>
            </div>
            <div className="text-3xl font-bold text-gray-900 mb-1">
              {analytics?.summary?.unused_licenses || 0}
            </div>
            <div className="text-sm text-gray-600">Unused Licenses</div>
            <div className="text-xs text-gray-500 mt-1">Save by canceling</div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Upcoming Renewals */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-indigo-600" />
              Upcoming Renewals
            </h2>
            {upcomingRenewals.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                No renewals in the next 30 days
              </div>
            ) : (
              <div className="space-y-3">
                {upcomingRenewals.slice(0, 5).map((sub) => {
                  const daysUntil = getDaysUntilRenewal(sub.renewal_date);
                  return (
                    <a
                      key={sub.id}
                      href={`/subscriptions/${sub.id}`}
                      className="block p-4 rounded-xl border border-gray-200 hover:border-indigo-300 hover:bg-indigo-50/50 transition-all"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="font-semibold text-gray-900">
                          {sub.name}
                        </div>
                        <div
                          className={`px-3 py-1 rounded-full text-xs font-bold ${
                            daysUntil <= 7
                              ? "bg-red-100 text-red-700"
                              : daysUntil <= 14
                                ? "bg-orange-100 text-orange-700"
                                : "bg-blue-100 text-blue-700"
                          }`}
                        >
                          {daysUntil} days
                        </div>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">
                          {formatDate(sub.renewal_date)}
                        </span>
                        <span className="font-semibold text-gray-900">
                          ${sub.price}
                        </span>
                      </div>
                    </a>
                  );
                })}
              </div>
            )}
          </div>

          {/* Spend by Category */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-indigo-600" />
              Spend by Category
            </h2>
            {analytics?.by_category?.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                No subscriptions yet
              </div>
            ) : (
              <div className="space-y-4">
                {analytics?.by_category?.map((cat) => (
                  <div key={cat.category}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-gray-900">
                        {cat.category}
                      </span>
                      <span className="text-sm text-gray-600">
                        ${parseFloat(cat.total).toFixed(2)}
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-gradient-to-r from-indigo-600 to-purple-600 h-2 rounded-full"
                        style={{
                          width: `${(parseFloat(cat.total) / parseFloat(analytics.summary.total_monthly_spend)) * 100}%`,
                        }}
                      ></div>
                    </div>
                    <div className="text-xs text-gray-500 mt-1">
                      {cat.count} subscriptions
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mt-8 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-2xl p-8 text-white">
          <h2 className="text-2xl font-bold mb-4">Getting Started</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <a
              href="/subscriptions/new"
              className="bg-white/10 backdrop-blur-sm rounded-xl p-4 hover:bg-white/20 transition-all"
            >
              <Plus className="w-8 h-8 mb-2" />
              <div className="font-semibold mb-1">Add Subscription</div>
              <div className="text-sm text-indigo-100">
                Track your software expenses
              </div>
            </a>
            <a
              href="/subscriptions"
              className="bg-white/10 backdrop-blur-sm rounded-xl p-4 hover:bg-white/20 transition-all"
            >
              <Package className="w-8 h-8 mb-2" />
              <div className="font-semibold mb-1">View All</div>
              <div className="text-sm text-indigo-100">
                Manage your subscriptions
              </div>
            </a>
            <a
              href="/browse"
              className="bg-white/10 backdrop-blur-sm rounded-xl p-4 hover:bg-white/20 transition-all"
            >
              <Sparkles className="w-8 h-8 mb-2" />
              <div className="font-semibold mb-1">Marketplace</div>
              <div className="text-sm text-indigo-100">Find great deals</div>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
